package com.example.n_back;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.logging.Level;

public class GameActivity extends AppCompatActivity {
    private GameFunction gameFunction;
    int buttonId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String buttonId = "";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        Intent intent = getIntent();
        this.buttonId = intent.getIntExtra(buttonId, 0);
        this.gameFunction = new GameFunction(this.buttonId);
    }

    public void clicked(View v){
        gameFunction.getAnswer();
        gameFunction.getRandomNumber();
    }
}