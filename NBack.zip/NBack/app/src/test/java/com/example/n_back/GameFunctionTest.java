package com.example.n_back;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GameFunctionTest {

    @Test
    public void test_01(){
        GameFunction gf = new GameFunction(R.id.b2);
        assertEquals(2, gf.getBtnNumb(R.id.b2));
    }

    @Test
    public void test_02(){
        GameFunction gf = new GameFunction(R.id.b2);
        gf.setup();
        if(gf.getBtnNumb(0)==gf.getBtnNumb(2)){
            gf.setInput(R.id.o);
        }else {
            gf.setInput(R.id.x);
        }
        assertEquals(3,gf.getLife());
    }

    @Test
    public void test_03(){
        GameFunction gf = new GameFunction(R.id.b2);
        gf.setup();
        if(gf.getBtnNumb(0)==gf.getBtnNumb(2)){
            gf.setInput(R.id.x);
        }else {
            gf.setInput(R.id.o);
        }
        assertEquals(2,gf.getLife());
    }

}