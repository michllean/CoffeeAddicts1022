package com.example.n_back;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.logging.Level;

public class GameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        Intent intent = getIntent();
    }

    public void answer(View view){

    }

    public void clicked(){
        GameFunction game = new GameFunction();
        LevelSelection level = new LevelSelection();
    }
}