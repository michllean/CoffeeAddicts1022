package com.example.n_back;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.logging.Level;

public class GameActivity extends AppCompatActivity {
    private GameFunction gameFunction;
    private int buttonId;
    private int btnIdNumber;
    private boolean start = false;
    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        Intent intent = getIntent();
        this.buttonId = intent.getIntExtra("intVariableName", 0);
        this.gameFunction = new GameFunction(this.buttonId);
    }

//    public void clicked(View v){
//        Intent mIntent = getIntent();
//        int intValue = mIntent.getIntExtra("intVariableName", 0);
//        if(intValue == R.id.b2){
//            ((TextView) findViewById(R.id.numberView)).setText("2");
//        }
//    }


    public void clicked(View v){
        btnIdNumber = gameFunction.getBtnNumb(buttonId);
        if(!start||counter<btnIdNumber+1){
           int n = gameFunction.setup();
           ((TextView) findViewById(R.id.numberView)).setText(Integer.toString(n));
           start = true;
           if(counter==btnIdNumber){
               ((Button) findViewById(R.id.x)).setText("X");
           }
            counter++;
        }else{
            gameFunction.setInput(v.getId());
            gameFunction.startGame();
            ((TextView) findViewById(R.id.numberView)).setText(Integer.toString(gameFunction.getGuessingNumber()));
            ((TextView) findViewById(R.id.life)).setText(Integer.toString(gameFunction.getLife()));
            if(gameFunction.getLife()==0){
                Bundle bundle = new Bundle();
                bundle.putString("YEET", Integer.toString(gameFunction.getLevel()));
                Intent intent = new Intent(this, EndScreen.class);
                intent.putExtras(bundle);
                startActivity(intent);
                finish();
            }
        }
    }
}