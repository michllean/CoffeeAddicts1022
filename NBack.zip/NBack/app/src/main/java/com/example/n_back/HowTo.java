package com.example.n_back;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class HowTo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_to);
        TextView info = (TextView) findViewById(R.id.infoPage);
        ((TextView) findViewById(R.id.sub2)).setText("\"update your memory with new items and forget the old ones\"");
        info.setText("1. Remember n numbers for each n-back level. The first n numbers are for the players to remember.\n");
        info.append("2. Matching starts when the button to the left changes to 'X'.\n");
        info.append("3. If the current number matches the number n before, click 'O'. If it does not match, click 'X'.");
    }
}