package com.example.n_back;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class LevelSelection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_selection);
    }

    public void startGame(View view){
        Intent intent = new Intent(LevelSelection.this, GameActivity.class);
        intent.putExtra("intVariableName", view.getId());
        startActivity(intent);
    }

    public void openInfo(View view){
        Intent intent = new Intent(this, HowTo.class);
        startActivity(intent);
    }

}