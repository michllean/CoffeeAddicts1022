package com.example.n_back;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class LevelSelection extends AppCompatActivity {
    private String buttonId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_selection);
    }

    public void startGame(View view){
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra(buttonId, view.getId());
        startActivity(intent);
        view.getId();
    }

}