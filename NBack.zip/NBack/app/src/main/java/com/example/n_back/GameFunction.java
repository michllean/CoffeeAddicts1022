package com.example.n_back;

public class GameFunction {
    private int buttonId;
    private boolean answer;
    private int[] numbers;
    private boolean end = false;

    public GameFunction(int button){numbers = new int[getBtnNumb(button)];}
    public GameFunction(String choice){}

    public int getBtnNumb(int button){
        int buttonId;
        switch(button){
            case R.id.b2:
                buttonId = 2;
                break;
            case R.id.b3:
                buttonId = 3;
                break;
            case R.id.b4:
                buttonId = 4;
                break;
            case R.id.b5:
                buttonId = 5;
                break;
            default:
                buttonId = 0;
                break;
        }
        return buttonId;
    }
    public void calculateAnswer(){

    }

    public boolean getAnswer(){
        return false;
    }

    public int getRandomNumber(){return (int)(Math.random()*10);}

    public boolean gameEnd(){
        return end;
    }
}
