package com.example.n_back;

public class GameFunction {
    public void gameLevel(){
        LevelSelection l = new LevelSelection();
    }
}
