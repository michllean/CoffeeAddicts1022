package com.example.n_back;

import android.view.View;

import java.util.ArrayList;

public class GameFunction {
    private int buttonId;
    private int[] numbers;
    private boolean end = false;
    private int input;
    private int guessingNumber;
    private int life = 3;
    private int startCounter = 0;
    private int level = 0;

    public GameFunction(int button){
        numbers = new int[getBtnNumb(button)+1];
    }

    public void setInput(View v){
        switch(v.getId()){
            case R.id.x:
                input = 0;
                break;
            case R.id.o:
                input = 1;
                break;
            default:
                input = -1;
                break;
        }
    }

    public int setup(){
        randomNumber();
        numbers[startCounter] = guessingNumber;
        startCounter++;
        return guessingNumber;
    }

    public int getGuessingNumber(){return guessingNumber;}

    public void startGame(){
        if((numbers[0]!=numbers[buttonId]&&input==1)||(numbers[0]==numbers[buttonId]&&input==0)){
            life--;
        }
        level++;
        //restores the number array with a new random number at the end of the index
        for(int i = 0; i < buttonId+1; i++){
            if(i==buttonId) {
                randomNumber();
                int n = guessingNumber;
                numbers[i] = n;
            }else{
                numbers[i]=numbers[i+1];
            }
        }
    }

    private void randomNumber(){guessingNumber = (int)(Math.random()*5)+1;}

    public boolean gameEnd(){
        return end;
    }

    public int getBtnNumb(int button){
        switch(button){
            case R.id.b2:
                this.buttonId = 2;
                break;
            case R.id.b3:
                this.buttonId = 3;
                break;
            case R.id.b4:
                this.buttonId = 4;
                break;
            case R.id.b5:
                this.buttonId = 5;
                break;
            default:
                this.buttonId = 0;
                break;
        }
        return this.buttonId;
    }


    public int getLife(){return life;}
    public int getLevel(){return level;}


}
